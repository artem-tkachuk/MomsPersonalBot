const formatNumber = (number: number) => {
    return number.toLocaleString('ru');
};

export default formatNumber;