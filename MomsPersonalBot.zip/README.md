# MomsPersonalBot
A simple chatbot in Telegram Messenger for my mom. Built with WebStorm, Azure, MongoDB and GitHub Actions
