import app from './src/index';

const port = process.env.PORT || 1337;

app.listen(port);

console.log(`Bot is running on the default port ${port}`);